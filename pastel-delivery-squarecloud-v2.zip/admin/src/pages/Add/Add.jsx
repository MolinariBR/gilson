import React, { useState } from "react";
import "./Add.css";
import { assets } from "../../assets/assets";
import axios from "axios";
import { toast } from "react-toastify";
import { useContext } from "react";
import { StoreContext } from "../../context/StoreContext";
import { useEffect } from "react";
import {useNavigate } from "react-router-dom";
import { getAdminTranslation } from "../../constants/adminTranslations";

const Add = ({url}) => {
  const navigate=useNavigate();
  const {token,admin} = useContext(StoreContext);
  const [image, setImage] = useState(false);
  const [categories, setCategories] = useState([]);
  const [data, setData] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
  });

  const onChangeHandler = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setData((data) => ({ ...data, [name]: value }));
  };

  // Fetch categories from database
  const fetchCategories = async () => {
    try {
      const response = await axios.get(`${url}/api/admin/categories`, {
        headers: { token }
      });
      
      if (response.data.success) {
        const activeCategories = response.data.data.filter(cat => cat.isActive);
        setCategories(activeCategories);
        
        // Set first category as default if no category is selected
        if (activeCategories.length > 0 && !data.category) {
          setData(prev => ({ ...prev, category: activeCategories[0].name }));
        }
      } else {
        toast.error(getAdminTranslation('categories.errorFetchingCategories', 'Error fetching categories'));
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
      toast.error(getAdminTranslation('categories.errorFetchingCategories', 'Error fetching categories'));
    }
  };

  const onSubmitHandler = async (event) => {
    event.preventDefault();
    const formData = new FormData();
    formData.append("name", data.name);
    formData.append("description", data.description);
    formData.append("price", Number(data.price));
    formData.append("category", data.category);
    formData.append("image", image);

    const response = await axios.post(`${url}/api/food/add`, formData,{headers:{token}});
    if (response.data.success) {
      setData({
        name: "",
        description: "",
        price: "",
        category: categories.length > 0 ? categories[0].name : "",
      });
      setImage(false);
      toast.success(getAdminTranslation('products.productAdded', response.data.message));
    } else {
      toast.error(getAdminTranslation('products.errorAddingProduct', response.data.message));
    }
  };
  useEffect(()=>{
    if(!admin && !token){
      toast.error(getAdminTranslation('authentication.pleaseLoginFirst', 'Please Login First'));
       navigate("/");
    } else {
      // Fetch categories when component mounts
      fetchCategories();
    }
  },[admin, token])
  return (
    <div className="add">
      <form onSubmit={onSubmitHandler} className="flex-col">
        <div className="add-img-upload flex-col">
          <p>{getAdminTranslation('products.uploadImage', 'Upload image')}</p>
          <label htmlFor="image">
            <img
              src={image ? URL.createObjectURL(image) : assets.upload_area}
              alt=""
            />
          </label>
          <input
            onChange={(e) => setImage(e.target.files[0])}
            type="file"
            id="image"
            hidden
            required
          />
        </div>
        <div className="add-product-name flex-col">
          <p>{getAdminTranslation('products.productName', 'Product name')}</p>
          <input
            onChange={onChangeHandler}
            value={data.name}
            type="text"
            name="name"
            placeholder={getAdminTranslation('products.typeHere', 'Type here')}
            required
          />
        </div>
        <div className="add-product-description flex-col">
          <p>{getAdminTranslation('products.productDescription', 'Product description')}</p>
          <textarea
            onChange={onChangeHandler}
            value={data.description}
            name="description"
            rows="6"
            placeholder={getAdminTranslation('products.writeContentHere', 'Write content here')}
            required
          ></textarea>
        </div>
        <div className="add-category-price">
          <div className="add-category flex-col">
            <p>{getAdminTranslation('products.productCategory', 'Product category')}</p>
            <select
              name="category"
              required
              onChange={onChangeHandler}
              value={data.category}
            >
              <option value="" disabled>
                {getAdminTranslation('products.selectCategory', 'Selecione uma categoria')}
              </option>
              {categories.map((category) => (
                <option key={category._id} value={category.name}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
          <div className="add-price flex-col">
            <p>{getAdminTranslation('products.productPrice', 'Product price')}</p>
            <input
              onChange={onChangeHandler}
              value={data.price}
              type="Number"
              name="price"
              placeholder="R$20"
              required
            />
          </div>
        </div>
        <button type="submit" className="add-btn">
          {getAdminTranslation('products.add', 'ADD')}
        </button>
      </form>
    </div>
  );
};

export default Add;
